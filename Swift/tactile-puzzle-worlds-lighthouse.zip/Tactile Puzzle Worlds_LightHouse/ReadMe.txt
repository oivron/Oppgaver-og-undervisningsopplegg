Swift Playgrounds Tactile Puzzle Worlds, Learn to Code 1 and Learn to Code 2

Welcome to the Swift Playgrounds Tactile Puzzle Worlds ReadMe, which contains essential information for printing and embossing the accompanying files. Learn more about Apple's Everyone Can Code curriculum and Swift Playgrounds here: https://www.apple.com/education/teaching-code/

Swift Playgrounds Tactile Puzzle Worlds contains:
--47 tactile puzzle worlds in Swift Playgrounds Learn to Code 1
--45 tactile puzzle worlds in Swift Playgrounds Learn to Code 2
--Key listing all features and textures used within the worlds
--Table of Contents for ease of navigation
--Text is written in Unified English Braille (UEB) Code

Printing and Embossing Instructions
This ZIP file contains files for printing tactile graphics. Several different files, both PRN and PDF, are included, each compatible with specific production methods. The PDF (Swell) is optimized for Swell-Touch Paper (often referred to as swell paper, capsule paper, microcapsule paper). PRN files are optimized for ViewPlus embossers. Tactile graphics are formatted for 11 x 11.5-inch paper. Those denoted "UK" are formatted for A3 (11.7" x 16.5"). 

ViewPlus
[Swift-Playgrounds_LearnToCode1_Columbia-Delta.prn] and [Swift-Playgrounds_LearnToCode2_Columbia-Delta.prn] are PRNs for printing on a ViewPlus Columbia or ViewPlus Delta embosser. (The PRN locks in all the settings, bypassing the print driver, so you get consistent results). 
[Swift-Playgrounds_LearnToCode1_Elite-Premier.prn] and [Swift-Playgrounds_LearnToCode2_Elite-Premier.prn] are PRNs for printing on ViewPlus Premier or ViewPlus Elite. 
[Swift-Playgrounds_LearnToCode1_Max.prn] and [Swift-Playgrounds_LearnToCode2_Max.prn] are PRNs for printing on ViewPlus Max. 
The tactile resolution of the Max, Premier, and Elite is 20 DPI, whereas the tactile resolution of Columbia and Delta is 100 DPI. The quality of the tactile graphics may differ based on embosser type.

Swell-Touch
[Swift-Playgrounds_LearnToCode1_Swell.pdf] and [Swift-Playgrounds_LearnToCode2_Swell.pdf] are PDFs optimized for Swell-Touch Paper. Simply print pages as you would for any Swell-Touch tactile graphics machine.
[Swift-Playgrounds_LearnToCode1_Swell_UK.pdf] is formatted for A3 (11.7" x 16.5").

Visual Only
[Swift-Playgrounds_LearnToCode1_Visual.pdf] and [Swift-Playgrounds_LearnToCode2_Visual.pdf] are large print Visual PDFs. These file are not intended for tactile graphics production and are for visual reference only.
[Swift-Playgrounds_LearnToCode1_Visual_UK.pdf]is formatted for A3 (11.7" x 16.5").

To order an embossed copy in North America, contact the Adaptations Store at LightHouse for the Blind and Visually Impaired:
 
Phone: 1-888-400-8933
 
Email: adaptations@lighthouse-sf.org 

Web: http://lighthouse-sf.org/shop/

To order an embossed copy in the UK, contact Royal National Institute for the Blind and Visually Impaired:
Phone: 01733 37370
Web: Businesslink@rnib.org.uk

Legal Notices

Copyright � 2019 Apple Inc. All rights reserved.
Swift Playground Tactile Puzzle Worlds are provided for educational purposes only and the commercial distribution or resale is strictly prohibited. 
Produced by LightHouse for the Blind and Visually Impaired, 1155 Market Street, 10th Floor, San Francisco, California 94103, USA. http://lighthouse-sf.org

ReadMe.txt_10-31-2019
